from flask import Flask, request, jsonify
import os
import fitz  # PyMuPDF
import mysql.connector
from werkzeug.utils import secure_filename
from config import DB_CONFIG, UPLOAD_FOLDER

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# Create uploads folder if not exist
if not os.path.exists(UPLOAD_FOLDER):
    os.makedirs(UPLOAD_FOLDER)

# Connect to MySQL
def get_db_connection():
    return mysql.connector.connect(**DB_CONFIG)

# Root route
@app.route('/')
def home():
    return "✅ QuizMakerApp backend is running!"

# Test database route
@app.route('/users', methods=['GET'])
def get_users():
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("SELECT id, username, email, role FROM users")
    users = cursor.fetchall()
    cursor.close()
    conn.close()
    return jsonify(users)

# Upload PDF route
@app.route('/upload', methods=['POST'])
def upload_pdf():
    if 'file' not in request.files:
        return jsonify({'error': 'No file part'}), 400

    file = request.files['file']
    if file.filename == '':
        return jsonify({'error': 'No file selected'}), 400

    filename = secure_filename(file.filename)
    filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
    file.save(filepath)

    # Extract text from PDF
    text = ""
    with fitz.open(filepath) as pdf:
        for page in pdf:
            text += page.get_text()

    return jsonify({
        'message': '✅ File uploaded and text extracted',
        'filename': filename,
        'extracted_text': text[:500]
    })

if __name__ == '__main__':
    app.run(debug=True)
