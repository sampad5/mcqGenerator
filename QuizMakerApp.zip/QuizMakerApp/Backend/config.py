
DB_CONFIG = {
    'host': 'localhost',
    'user': 'root',
    'password': 'Piyush19',
    'database': 'QuizMakerApp'
}

UPLOAD_FOLDER = 'uploads'
